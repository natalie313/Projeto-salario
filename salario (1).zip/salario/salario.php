<?php 
header('Content-Type: text/html; charset=utf-8');

//variaveis
$nome = $_POST["nome"];
$qntd = $_POST["qntd"];
$hora =$_POST["hora"];
$turno = $_POST["turno"];
$salario = $qntd * $hora;
$porcentagem = 0;
$total =0;
$FGTS = 0;
$inss = 0;

if(isset($_POST["Calcular"]) &&
isset($_POST["qntd"]) && !empty ($_POST["qntd"]) &&
isset($_POST["hora"]) && !empty ($_POST["hora"]) &&
isset($_POST["turno"]) && !empty ($_POST["turno"])){


    if ($turno = "noturno"){
       $porcentagem = $salario * 0.2;
       $total = $porcentagem + $salario;
       $FGTS = $total - 0.08;
       $inss = $total - 0.04;

        echo "<br> O nome é: ".$nome; 
        echo "<br> A quantidade de horas é de: ".$qntd; 
        echo " <br> A hora indicada foi: ".$hora;
        echo " <br> Turno escolhido: ".$turno;
        echo "<br> Salário com o acrescimo R$: ".$total;
        echo "<br> Valor com o FGTS R$: ".$FGTS;
        echo "<br> Valor com o INSS R$: ".$inss;

    }
    else{
        $porcentagem = $salario * 0.2;
        $total = $porcentagem + $salario;
        $FGTS = $total - 0.08;
        $inss = $total - 0.04;

        echo "<br> O nome é: ".$nome; 
        echo "<br> A quantidade de horas é de: ".$qntd; 
        echo " <br> A hora indicada foi: ".$hora;
        echo " <br> Turno escolhido: ".$turno;
        echo "<br> Salário com o acrescimo R$: ".$total;
        echo "<br> Valor com o FGTS R$: ".$FGTS;
        echo "<br> Valor com o INSS R$: ".$inss;
    }
       
   
}
?>
